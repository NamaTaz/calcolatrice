/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany._giovinemichelle_calcolatrice;

/**
 *
 * @author Michelle
 */
public class App {

    public static void main(String[] args) {
        calculator calc = new calculator();
        calc.setVisible(true);
    }
}
